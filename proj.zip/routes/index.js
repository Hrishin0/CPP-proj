var express = require('express');
var router = express.Router();
const connection = require('../database'); 

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Event Lord', name:null });
});

router.post('/', function(req, res, next) {

  res.render('index', { title: 'Event Lord', name:req.body.name });
});

router.get('/page2', function(req, res, next) {
  res.render('page2', { title: 'Event Lord', name:null });
});


router.get('/page3', function(req, res, next) {
  res.render('page3', { title: 'Event Lord', name:null });
});

router.get('/page4', function(req, res, next) {
  res.render('page4', { title: 'Event Lord', name:null });
});


router.get('/page5', function(req, res, next) {
  res.render('page5', { title: 'Event Lord', name:null });
});

router.get('/page6', function(req, res, next) {
  res.render('page6', { title: 'Event Lord', name:null });
});

router.get('/page1', function (req, res, next) {
  connection.query('SELECT * FROM Events ORDER BY id desc', function (err, rows) {
    if (err) {
      req.flash('error', err)
      res.render('page1', { data: '' })
    } else {
      res.render('page1', { data: rows })
    }
  })
})

router.delete('/events/:id', function(req, res, next) {
  const eventId = req.params.id; // Extract event ID from URL parameter

  // Database query to delete the event
  connection.query('DELETE FROM Events WHERE id = ?', [eventId], function(err, result) {
    if (err) {
      console.error('Error deleting event:', err);
      return res.status(500).send('Error deleting event');
    }
    res.status(200).send('Event deleted successfully');
  });
});

  
module.exports = router;


